package com.manas.message.messenger.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Profile {
	
	private Long profileId;
	private String profileName;
	private String profileCreated;
	private String profileDob;
	private Likes like;
	
	public Likes getLike() {
		return like;
	}
	public void setLike(Likes like) {
		this.like = like;
	}
	public Profile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Profile(Long profileId, String profileName, String profileCreated, String profileDob,Likes like) {
		super();
		this.profileId = profileId;
		this.profileName = profileName;
		this.profileCreated = profileCreated;
		this.profileDob = profileDob;
		this.like = like;
	}
	public Long getProfileId() {
		return profileId;
	}
	public void setProfileId(Long profileId) {
		this.profileId = profileId;
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	public String getProfileCreated() {
		return profileCreated;
	}
	public void setProfileCreated(String profileCreated) {
		this.profileCreated = profileCreated;
	}
	public String getProfileDob() {
		return profileDob;
	}
	public void setProfileDob(String profileDob) {
		this.profileDob = profileDob;
	}
	

}
