package com.manas.message.messenger.model;


import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class Message {
	private long id;
	private String message;
	private String created;
	private String author;
	private Likes like;
	
	public Likes getLike() {
		return like;
	}


	public void setLike(Likes like) {
		this.like = like;
	}

	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Message(long long1, String string, String String, String string2,Likes like) {

		this.id = long1;
		this.message = string;
		this.created = String;
		this.author = string2;
		this.like=like;
		}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	
}



