package com.manas.message.messenger.model;

public class Likes {
	
	private String likeCount;
	private String likeId;
	private Long profileId;
	private String LikeCreated;
	private Long messageId;
	
	public String getLikeCreated() {
		return LikeCreated;
	}
	public void setLikeCreated(String likeCreated) {
		LikeCreated = likeCreated;
	}
	public Long getMessageId() {
		return messageId;
	}
	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}
	public Likes() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Likes(String likeCount, String likeId, Long profileId,String LikeCreated) {
		super();
		this.likeCount = likeCount;
		this.likeId = likeId;
		this.profileId = profileId;
		this.LikeCreated= LikeCreated;
	}
	public String getLikeCount() {
		return likeCount;
	}
	public void setLikeCount(String likeCount) {
		this.likeCount = likeCount;
	}
	public String getLikeId() {
		return likeId;
	}
	public void setLikeId(String likeId) {
		this.likeId = likeId;
	}
	public Long getProfileId() {
		return profileId;
	}
	public void setProfileId(Long profileId) {
		this.profileId = profileId;
	}

}
