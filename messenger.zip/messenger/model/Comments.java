package com.manas.message.messenger.model;

public class Comments {

}
