package com.manas.message.messenger.resource;


import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.manas.message.messenger.model.Message;
import com.manas.message.messenger.service.MessageService;
@Path("messages")
public class MessageResource {

	MessageService messageservice=new MessageService();

	@GET
//	@Produces(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	
	public List<Message> getAllMessages() {
		//return messages.toString();
		return messageservice.getAllMessages();
		//return "Hello world RestFul Api....";
	}
	
	@Path("/{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Message> getMessage(@PathParam("id") Long id){
		
		return  messageservice.getMessage(id);
		
	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String addMessage(Message message){
		
		return messageservice.addMessage(message);
		
	}
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	public String updateMessage(Message message){
		return messageservice.updateMessage(message);
		
	}
}
