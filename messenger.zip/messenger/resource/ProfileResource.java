package com.manas.message.messenger.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.manas.message.messenger.model.Likes;
import com.manas.message.messenger.model.Message;
import com.manas.message.messenger.model.Profile;
import com.manas.message.messenger.service.ProfileService;


@Path("/profile")
public class ProfileResource {
	
	ProfileService profileservice=new ProfileService();
	
	
	@Path("/{profileId}/likes")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Likes> getAllLikes(@PathParam("profileId") Long profileId){
		
		return profileservice.getAllLikes(profileId);
	}
	@Path("/{profileId}/comments")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Likes> getAllComments(@PathParam("profileId") Long profileId){
		
		return profileservice.getAllComments(profileId);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Profile> getAllProfiles() {
		
		return profileservice.getAllProfiles();

	}
	@Path("/{profileId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Profile> getProfile(@PathParam("profileId") Long profileId ) {
		
		return profileservice.getProfile(profileId);

	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String addProfile(Profile profile){
		return profileservice.addProfile(profile);
		
	}
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	public String updateProfile(Profile profile){
		return profileservice.updateProfile(profile);
		
	}

}
