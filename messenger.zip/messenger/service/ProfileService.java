package com.manas.message.messenger.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.manas.message.messenger.database.DatabaseConnection;
import com.manas.message.messenger.model.Likes;
import com.manas.message.messenger.model.Message;
import com.manas.message.messenger.model.Profile;

public class ProfileService {
	
	Connection con=(new DatabaseConnection()).getConnection();
	Statement statement=null;
	ResultSet resultset = null;
	ArrayList<Profile> profileList = new ArrayList<Profile>();
	Likes like=new Likes();

	final static String SUCCESS="Record Added Successfully...";
	final static String FALIURE="Failed to Add or Update...";
	
	public List<Profile> getAllProfiles(){
		 String selectQuery = "Select * From profiles";
		 String selectQueryLike = "Select * From likes where messageid=?";

		    try {
		    	statement = con.createStatement();
			    resultset = statement.executeQuery(selectQuery);
			    while (resultset.next()) {
		    	
		        Profile profile = new
		   Profile(resultset.getLong("profileId"), resultset.getString("ProfileName"), resultset.getString("profileCreated"), resultset.getString("profileDob"),like);
		        profileList.add(profile);
		    }
		   // con.close();
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   /* if(messageList.isEmpty()) {
		    	return "Database Does not return";
		    }*/
		    return profileList;

	}

	public List<Profile> getProfile(Long id) {
		System.out.print(id);
		PreparedStatement pstmt =null;
		 ArrayList<Profile> profileList = new ArrayList<Profile>();
		 ResultSet resultset = null;
		 String selectQuery = "Select * From profiles where profileId=?";
		 String selectQueryLike = "Select * From likes where profileid=?";

		    try {
		    	pstmt = con.prepareStatement(selectQueryLike);	
		    	pstmt.setLong(1, id);
			    resultset = pstmt.executeQuery();
			    while (resultset.next()) {
		    	
			    	like.setLikeCount(resultset.getString("likecount"));
			    	like.setLikeCreated(resultset.getString("likeCreated"));
		      		    }
			    
		    	 pstmt = con.prepareStatement(selectQuery);	
		    	pstmt.setLong(1, id);
			    resultset = pstmt.executeQuery();
			    while (resultset.next()) {
		    	
		        Profile profile = new
		        		Profile(resultset.getLong("profileId"), resultset.getString("ProfileName"), resultset.getString("profileCreated"), resultset.getString("profileDob"),like);
		        profileList.add(profile);
		  }
		   // con.close();
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   /* if(messageList.isEmpty()) {
		    	return "Database Does not return";
		    }*/
		    return profileList;

	}

	public String addProfile(Profile profile) {
		String query = "INSERT INTO profiles VALUES (?, ?, ?, ?)";
	      try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setLong(1, profile.getProfileId());
			pstmt.setString(2, profile.getProfileName());
			
			System.out.print(profile.getProfileCreated());
			Date date=Date.valueOf(profile.getProfileCreated());
			
			System.out.print(date);

			pstmt.setDate(3, date);
			Date dob=Date.valueOf(profile.getProfileDob());
			
			System.out.print(dob);

			pstmt.setDate(4, dob);
			
			pstmt.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return ProfileService.FALIURE;
		}
	     // profile.setMessage("Record Added Successfully...");
		return ProfileService.SUCCESS;
		}

	public String updateProfile(Profile profile) {
		// TODO Auto-generated method stub
		return ProfileService.SUCCESS;
	}

	public List<Likes> getAllLikes(Long profileId) {
		System.out.print(profileId);
		PreparedStatement pstmt =null;
		 ArrayList<Likes> likeList = new ArrayList<Likes>();
		 ResultSet resultset = null;
		 String selectQuery = "Select * From likes where profileId=?";
		    try {
		    	 pstmt = con.prepareStatement(selectQuery);	
		    	pstmt.setLong(1, profileId);
			    resultset = pstmt.executeQuery();
			    while (resultset.next()) {
		    	
		        Likes like = new
		   Likes(resultset.getString("likeCount"),
			resultset.getString("likeId"), resultset.getLong("profileId"),resultset.getString("LikeCreated"));
		        likeList.add(like);
		    }
		   // con.close();
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   /* if(messageList.isEmpty()) {
		    	return "Database Does not return";
		    }*/
		    return likeList;
	}

	public List<Likes> getAllComments(Long profileId) {
		// TODO Auto-generated method stub
		return null;
	}
}
