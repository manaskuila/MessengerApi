package com.manas.message.messenger.service;

import java.sql.*;

import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import com.manas.message.messenger.database.DatabaseConnection;
import com.manas.message.messenger.model.*;

public class MessageService {
	Connection con=(new DatabaseConnection()).getConnection();
	Connection con1=(new DatabaseConnection()).getConnection();

	Likes like=new Likes();
	final static String SUCCESS="Record Added Successfully...";
	final static String FALIURE="Failed to Add or Update...";
	 ArrayList<Message> messageList = new ArrayList<Message>();
	 Message message;
	PreparedStatement pstmt,pstmtLike =null;
	ResultSet resultset,resultsetlike = null;

	public List<Message> getAllMessages(){
	
		String selectQueryLike = "Select * From messages m,likes l where m.id=l.messageid";
		    try {
		    	 pstmt = con1.prepareStatement(selectQueryLike);	
			    	resultsetlike = pstmt.executeQuery();
			    while (resultsetlike.next()) {
				    	like.setLikeCount(resultsetlike.getString("likecount"));
				    	like.setLikeCreated(resultsetlike.getString("likeCreated"));
			      	     message = new
		   Message(resultsetlike.getLong("id"), resultsetlike.getString("message"), 
				   resultsetlike.getString("created"), resultsetlike.getString("author"),
				   like);
		        messageList.add(message);
		    }
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   
		    return messageList;
	}
	public List<Message> getMessage(Long id){
		 String selectQuery = "Select * From messages where id=?";
		 String selectQueryLike = "Select * From likes where messageid=?";

		    try {
		    	pstmt = con.prepareStatement(selectQueryLike);	
		    	pstmt.setLong(1, id);
			    resultset = pstmt.executeQuery();
			    while (resultset.next()) {
		    	
			    	like.setLikeCount(resultset.getString("likecount"));
			    	like.setLikeCreated(resultset.getString("likeCreated"));
		      		    }
		    	
		    	 pstmt = con.prepareStatement(selectQuery);	
		    	pstmt.setLong(1, id);
			    resultset = pstmt.executeQuery();
			    while (resultset.next()) {
		    	
		         message = new
		   Message(resultset.getLong("id"), resultset.getString("message"), resultset.getString("created"), resultset.getString("author"),
				  like );
		        messageList.add(message);
		    }
		   // con.close();
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
		
		    return messageList;
	}
	public String addMessage(Message message) {
		String queryLike = "INSERT INTO likes(messageId,LikeCreated) values (?,?)";

		String query = "INSERT INTO messages VALUES (?, ?, ?, ?)";
	      try {
	    	pstmtLike = con.prepareStatement(queryLike);
	    	pstmtLike.setLong(1, message.getId());
	    	pstmtLike.setDate(2, Date.valueOf(message.getCreated()));

	    	pstmtLike.execute();
	    	pstmt = con.prepareStatement(query);
			pstmt.setLong(1, message.getId());
			pstmt.setString(2, message.getMessage());
			pstmt.setDate(3, Date.valueOf(message.getCreated()));
			pstmt.setString(4, message.getAuthor());
			
			pstmt.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return MessageService.FALIURE;
		}
	      
		return MessageService.SUCCESS;
	}
	public String updateMessage(Message message) {
		
		String query="update messages set message=?,created=?,author=? where id=?";
		try {
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, message.getMessage());
			pstmt.setDate(2,Date.valueOf(message.getCreated()));
			pstmt.setString(3, message.getAuthor());
			pstmt.setLong(4, message.getId());
		}
		catch(SQLException e) {
			e.printStackTrace();
			return MessageService.FALIURE;

		}
		return MessageService.SUCCESS;
	}
}
